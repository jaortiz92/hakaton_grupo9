package com.misiontic_hackaton.game_ms.exceptions;

public class GameException extends RuntimeException {
    public GameException(String message) {
        super(message);
    }
}